using {saphira.assinatura as db} from '../db/schema';

using {
  saphira.assinatura.IasLogin,
  saphira.assinatura.RtId,
  saphira.assinatura.SignId,
  saphira.assinatura.Contexto,
  saphira.assinatura.Digest,
  saphira.assinatura.TipoAcao,
  saphira.assinatura.ObjetoTipo
} from '../db/types';

service AssinaturaService @(requires: 'authenticated-user') {

  @readonly
  entity Livros               as projection on db.Livros;

  /** Cada RT so enxerga o proprio cadastro - inclusive a imagem de assinatura. */
  @readonly
  @(restrict: [{
    grant: 'READ',
    where: 'login = $user'
  }])
  entity ResponsaveisTecnicos as projection on db.RtAssinatura {
    ID,
    login,
    rtId,
    nome,
    crf,
    status,
    validoDe,
    validoAte,
    imgData,
    imgMimeType
  };

  @readonly
  entity Eventos              as projection on db.AssinaturaEventos;

  type Preparo {
    contexto     : Contexto;
    login        : IasLogin;
    rtId         : RtId;
    nome         : String(120);
    imagemUrl    : String(400);
    stepUpId     : UUID;

    /** Nulo quando nao ha binding do IAS - nesse caso a prova vem do mock. */
    authorizeUrl : String(2000);

    /** Origem esperada do postMessage do popup de step-up. */
    callbackOrigin : String(200);

    /** Falso quando o IdP corporativo ja comprova o segundo fator. */
    exigeTotp      : Boolean;

    /** Falso quando o RT ainda nao cadastrou o segundo fator - sem ele nao ha assinatura. */
    totpAtivo      : Boolean;
  }

  type Resultado {
    signId        : SignId;
    rtId          : RtId;
    signImageHash : Digest;
    assinadoEm    : Timestamp;
    objetoTipo    : ObjetoTipo;
    objetoId      : UUID;
  }

  /** Devolvido uma unica vez, no enrolamento. O segredo nunca mais sai do servidor. */
  type EnrolamentoTotp {
    segredo       : String(64);
    otpauthUri    : String(400);
    digitos       : Integer;
    passoSegundos : Integer;
  }

  /** Passos 2 e 3: elegibilidade do RT e montagem do conteudo do dialogo. */
  function prepararAssinatura(tipoAcao : TipoAcao, objetoId : UUID)                      returns Preparo;

  /** Passos 6 a 9. O objeto assinado vem da prova, nao do cliente. */
  action   assinarEletronicamente(proofId : String(64)                            @mandatory,
                                  declaracaoConformidade : Boolean                @mandatory,
                                  codigoTotp : String(10))                                     returns Resultado;

  /**
   * Cadastro do segundo fator do proprio RT. Existe porque o IAS nao emite `amr`:
   * sem um fator sob controle da aplicacao nao ha como provar que houve dois fatores.
   */
  action   iniciarEnrolamentoTotp()                                                     returns EnrolamentoTotp;
  action   confirmarEnrolamentoTotp(codigo : String(10) @mandatory)                     returns Boolean;

  /**
   * Emissor de prova falso, usado enquanto o step-up real do IAS nao existe.
   * O handler recusa execucao em producao. Ver pendencia P7 no readme.
   */
  action   provarStepUpMock(stepUpId : UUID @mandatory)                                                          returns String;
}
