namespace saphira.assinatura;

using {
  cuid,
  managed
} from '@sap/cds/common';

using {
  saphira.assinatura.IasLogin,
  saphira.assinatura.RtId,
  saphira.assinatura.SignId,
  saphira.assinatura.Contexto,
  saphira.assinatura.Digest,
  saphira.assinatura.Fatores,
  saphira.assinatura.RtStatus,
  saphira.assinatura.LivroStatus,
  saphira.assinatura.EventoTipo,
  saphira.assinatura.StepUpStatus,
  saphira.assinatura.TipoAcao,
  saphira.assinatura.ObjetoTipo
} from './types';

/**
 * Cadastro dos Responsaveis Tecnicos habilitados a assinar.
 * Nao guarda senha nem token - a credencial vive apenas no IAS.
 */
entity RtAssinatura : cuid, managed {
      login       : IasLogin @mandatory;
      rtId        : RtId     @mandatory;
      nome        : String(120);
      crf         : String(20);
      status      : RtStatus default #ativo;
      validoDe    : Date;
      validoAte   : Date;
      imgData     : LargeBinary @Core.MediaType  : imgMimeType;
      imgMimeType : String(60)  @Core.IsMediaType;

      /** Calculado uma unica vez no cadastro da imagem e reconferido ao assinar. */
      imgHash     : Digest;
      hashAlg     : String(20) default 'HMAC-SHA256';

      /** Versao da chave no Credential Store, para permitir rotacao. */
      keyVersion  : String(10);
}

/** Objeto assinado. Recebe a evidencia da assinatura, nunca a credencial. */
entity Livros : cuid, managed {
      numero        : String(10) @mandatory;
      descricao     : String(120);
      substancia    : String(120);
      status        : LivroStatus default #aberto;
      signId        : SignId;
      signRt        : Association to RtAssinatura;
      signImageHash : Digest;
      signedAt      : Timestamp;
}

/**
 * Audit trail. Append-only: nunca sofre UPDATE nem DELETE.
 * Gravado em transacao propria para sobreviver ao rollback da operacao que falhou.
 */
entity AssinaturaEventos : cuid {
      evento     : EventoTipo @mandatory;
      occurredAt : Timestamp  @mandatory;
      tipoAcao   : TipoAcao;
      contexto   : Contexto;
      login      : IasLogin;
      rtId       : RtId;
      signId     : SignId;
      objetoTipo : ObjetoTipo;
      objetoId   : UUID;

      /** Sessao do IAS que autenticou a assinatura. Ponte para o log do provedor. */
      sessionId  : String(64);

      /** Fatores que a aplicacao de fato verificou, ex. `IAS+TOTP`. */
      fatores    : Fatores;

      /** Motivo tecnico interno. Nunca e devolvido ao cliente. */
      motivo     : String(200);
      origemIp   : String(45);
}

/** Anti-brute-force. Persistido porque a app roda em multiplas instancias. */
entity AssinaturaTentativas {
    key login        : IasLogin;
        failCount    : Integer default 0;
        lastFailAt   : Timestamp;
        blockedUntil : Timestamp;
}

/**
 * Segundo fator sob controle da aplicacao (TOTP, RFC 6238).
 * Existe porque o IAS nao emite `amr`/`acr`: sem isto nao ha como provar
 * que houve dois fatores, apenas confiar numa configuracao externa.
 */
entity AssinaturaTotp {
    key login         : IasLogin;

        /** Segredo cifrado com AES-256-GCM. Nunca trafega nem e persistido em claro. */
        segredo       : String(400) @mandatory;
        keyVersion    : String(10);
        digitos       : Integer     default 6;
        passoSegundos : Integer     default 30;
        criadoEm      : Timestamp;

        /** Nulo enquanto o enrolamento nao foi confirmado com um codigo valido. */
        ativadoEm     : Timestamp;

        /** Ultimo passo de tempo aceito. Impede replay do mesmo codigo. */
        ultimoPasso   : Integer64;
}

/**
 * Prova de step-up authentication. Substitui os campos senha/token do mockup.
 * Ciclo: PENDENTE (authorize emitido) -> PROVADO (id_token validado) -> CONSUMIDO (assinatura feita).
 */
entity AssinaturaStepUp : cuid {
      state        : String(64) @mandatory;

      /** PKCE e nonce. Segredos de vida curta e uso unico; apagados ao promover a prova. */
      codeVerifier : String(128);
      nonce        : String(64);
      login        : IasLogin  @mandatory;
      tipoAcao     : TipoAcao;
      contexto     : Contexto;
      objetoTipo   : ObjetoTipo;
      objetoId     : UUID;
      status       : StepUpStatus default #pendente;
      proofId      : String(64);
      subject      : String(120);

      /** Metodos de autenticacao devolvidos pelo IAS - evidencia do segundo fator. */
      amr          : String(200);

      /** `sid` do id_token: correlaciona esta assinatura com o log de autenticacao do IAS. */
      sessionId    : String(64);
      authTime     : Timestamp;
      issuedAt     : Timestamp;
      validUntil   : Timestamp;
      consumedAt   : Timestamp;
}
