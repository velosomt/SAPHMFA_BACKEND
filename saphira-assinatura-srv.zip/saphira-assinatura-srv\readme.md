# Getting Started

Welcome to your new CAP project.
## Estrutura

```
db/
  schema.cds          entidades
  types.cds           tipos e enums reutilizáveis
  data/               carga inicial (CSV)
srv/
  assinatura-service.cds     contrato OData
  assinatura-service.js      handlers finos — só orquestração
  server.js                  bootstrap + callback OIDC
  lib/
    config.js         ponto único de leitura de ambiente
    errors.js         AssinaturaError + chaves i18n
    entities.js       nomes qualificados das entidades
    domain/           regras puras, sem I/O e sem cds
    repo/             acesso a dados, CQN e colunas explícitas
    usecases/         casos de uso, orquestram domain + repo + infra
    infra/            IAS, HMAC, geração de imagem
scripts/              carga de dados
test/
  domain.test.js      unitário, sem servidor
  assinatura.test.js  integração, sobe o serviço
```

Regra de dependência: `srv` → `usecases` → `domain` / `repo` / `infra`. O domínio não importa nada.

It contains these folders and files, following our recommended project layout:

File or Folder | Purpose
---------|----------
`app/` | content for UI frontends goes here
`db/` | your domain models and data go here
`srv/` | your service models and code go here
`readme.md` | this getting started guide

## Como rodar localmente

```bash
npm ci
cp .env.example .env          # preencha os valores; ver "Configuração" abaixo
npm run setup:local           # cria o banco e gera as imagens de assinatura
npm start                     # http://localhost:4004
```

A UI é um projeto separado (`saphira-assinatura-ui`): `npm ci && npm start` → `http://localhost:8080`.
Ela faz proxy de `/odata` para `localhost:4004`, então o serviço precisa estar no ar.

Autenticação local é mockada: qualquer login da tabela de RTs com a senha `local`.

> Use sempre `npm run setup:local`, nunca `deploy:local` sozinho. Os CSVs não carregam binário, então o banco ficaria sem as imagens de assinatura — e aí toda assinatura é recusada pela verificação de integridade, o que parece bug mas está correto.

## Configuração

Todo acesso a ambiente passa por `srv/lib/config.js`. Nenhum outro módulo lê `process.env`.

| Variável | Obrigatória | Para quê |
|---|---|---|
| `SIGN_HMAC_KEY_DEV` / `SIGN_HMAC_KEY` | sim | HMAC da imagem de assinatura. `_DEV` local, sem sufixo em produção |
| `IAS_CREDENTIALS` | sim (local) | Service key do IAS, em JSON. Na nuvem vem de `VCAP_SERVICES` |
| `UI_ORIGIN` | sim | Origem esperada do `postMessage` do popup de step-up |
| `APP_BASE_URL` | nuvem | URL pública, usada para montar o `redirect_uri` |
| `MFA_CLAIM` / `MFA_CLAIM_VALUE` | não | Evidência de MFA vinda do IdP corporativo |
| `TOTP_OBRIGATORIO` / `TOTP_ENC_KEY(_DEV)` | não | Segundo fator próprio |

Produção falha fechada nas chaves: nunca cai no valor de desenvolvimento.

### Autenticação: quem faz o quê

```
Navegador → approuter (XSUAA) → CAP          ← quem autentica a aplicação
                ↓
           popup do IAS (OIDC, prompt=login) ← quem prova a identidade no ato de assinar
                ↓
           Entra ID (SAML)                   ← quem de fato pede o segundo fator
```

Três coisas diferentes, e é comum confundi-las:

- **XSUAA** autentica o acesso à aplicação. É o binding normal do CAP (`requires.auth`).
- **IAS** é usado **exclusivamente** para o step-up da assinatura, via authorization code + PKCE, com `prompt=login` e `max_age=0` para forçar reautenticação. Não substitui o XSUAA.
- **Entra ID** entra quando o IAS está federado a um IdP corporativo. É lá que o MFA acontece no cliente.

> **Nunca faça `cds bind` do serviço `identity`.** Qualquer binding com esse label faz o CAP trocar a estratégia de autenticação da aplicação inteira para `ias`, ignorando o profile — e isso quebra o auth mockado de desenvolvimento. Por isso as credenciais vêm de `IAS_CREDENTIALS` no `.env` e de `VCAP_SERVICES` na nuvem. `config.credenciaisIas` cobre os dois casos e **nunca** lê `requires.auth`.

### Configuração no IAS

Na aplicação criada pelo binding do serviço `identity`:

1. **Redirect URI** — `Trust` → `Single Sign-On` → configuração OIDC:
   - local: `http://localhost:4004/assinatura/stepup/callback`
   - nuvem: `https://<host-do-srv>/assinatura/stepup/callback`
2. **Client secret** — o `mta.yaml` já pede `credential-type: SECRET`, porque a troca do authorization code usa Basic auth.
3. **Evidência de MFA** (opcional, só com IdP corporativo) — `Trust` → `Single Sign-On` → `Attributes`, origem *Expression*:
   ```
   evidenciaMfa = ${corporateIdP.http://schemas.microsoft.com/claims/authnmethodsreferences}
   ```
   Depois, no ambiente da aplicação: `MFA_CLAIM=evidenciaMfa` e `MFA_CLAIM_VALUE=multipleauthn`.

O nome `amr` **não** funciona: o IAS o bloqueia explicitamente. Detalhes e evidências em "Evidência de MFA".

### Entra ID como IdP corporativo

Quando o IAS está federado ao Entra (cenário do cliente), o segundo fator acontece no Entra, não no IAS. Dois pré-requisitos para a evidência chegar:

| Requisito | Onde | Por quê |
|---|---|---|
| *Use Identity Authentication user store* habilitado | IAS → Corporate Identity Providers → Identity Federation | Sem isso o `${corporateIdP.*}` não resolve |
| Conditional Access com *Sign-in frequency: every time* | Entra, na aplicação do IAS | Senão `multipleauthn` pode se referir a um MFA de horas antes |

Ambos são configuração de tenant e exigem o time de identidade. Sem eles, use `TOTP_OBRIGATORIO=true` como alternativa.

## Pendências de plataforma

Itens conscientemente adiados para não bloquear o desenvolvimento local. Todos precisam estar fechados antes do deploy.

| # | Pendência | Onde impacta | Bloqueia |
|---|---|---|---|
| P1 | Provisionar `credstore` (plano `trial`) e gravar a chave HMAC da assinatura | `srv/lib/signature-hash.js` → `readCredstoreKey()` hoje lança erro | Deploy em produção |
| P2 | Provisionar `hana-cloud` (plano `hana-free`) e rodar o deploy do schema | `db/` | Deploy |
| P3 | Suportar rotação de chave com lookup por `keyVersion` | `verifyImageDigest()` hoje recusa tags de versão não ativa | Primeira rotação |
| P4 | Registrar o `redirect_uri` do callback de step-up na instância `trial-identity` | `cf update-service trial-identity -c ...` | Fase 5 (IAS real) |
| P5 | Gerar `mta.yaml` (`cds add mta`) — não foi criado por ausência de modelo no scaffold | raiz do projeto | Deploy |
| P6 | Instalar `mbt` (`npm i -g --allow-scripts=mbt mbt`) | build MTA | Deploy |
| P7 | Remover a action `provarStepUpMock` antes do deploy produtivo | `srv/assinatura-service.cds` e `srv/lib/step-up.js` | Deploy |
| P8 | Definir `APP_BASE_URL` e `UI_ORIGIN` no ambiente da nuvem e registrar o redirect da rota real | `srv/server.js`, `srv/lib/step-up.js` | Deploy |
| P9 | **Resolvida por decisão de arquitetura.** Ver "Evidência de MFA" e "Decisão: segundo fator próprio" abaixo | `srv/lib/infra/ias-client.js`, `srv/lib/domain/totp.js` | — |
| P10 | Criar índices em `AssinaturaStepUp.proofId`, `AssinaturaStepUp.state` e `AssinaturaEventos.signId`. Devem ser validados contra o HANA real e só então versionados como `.hdbindex` em `db/src/` | `db/src/` | Volume de produção |
| P11 | Recuperação do segundo fator: hoje um RT que perde o dispositivo fica sem assinar. Precisa de reset administrativo auditado | `AssinaturaTotp` | Operação |

> `@assert.unique` foi testado e **descartado**: o CAP o implementa como verificação em runtime (um SELECT extra por operação) e não gera constraint nem índice no banco — o `hdbtable` sai apenas com `PRIMARY KEY(ID)`. Custo sem benefício.

> P4 está feito para localhost (`http://localhost:4004/assinatura/stepup/callback`). Falta a URL da nuvem.

### Evidência de MFA

Testado com Risk-Based Authentication exigindo TOTP, primeiro no ambiente local e depois na aplicação da nuvem. O segundo fator **é** solicitado (QR code e código de 6 dígitos), mas o `id_token` **não traz `amr` nem `acr`** em nenhum dos dois. Claims recebidos na nuvem:

```
app_tid, aud, auth_time, azp, email, exp, family_name, given_name, ias_iss,
iat, iss, jti, nonce, sap_id_type, scim_id, sid, sub, user_uuid
```

Não é limitação de configuração — é do produto. O discovery do tenant confirma:

```
GET https://<tenant>/.well-known/openid-configuration

claims_supported:     iss, ias_iss, iat, exp, auth_time, sid, jti, nonce, sub, email,
                      email_verified, given_name, middle_name, family_name,
                      preferred_username, name, scim_id, groups, aud, azp,
                      app_tid, ias_apis, at_hash, sap_id_type, sap_gtid
acr_values_supported: (vazio)
```

A lista bate com a documentação oficial de claims do IAS, que também não inclui `amr`/`acr`. E como `acr_values_supported` vem vazio, o IAS **nem aceita** `acr_values` no pedido de autorização — não dá para exigir um nível de autenticação no request.

Conclusão: **não é possível exigir segundo fator lendo o token**. Uma validação de `amr` recusaria 100% das assinaturas.

### Isso não é limitação do trial

Verificado contra `accounts.sap.com` — o tenant IAS produtivo da própria SAP. Resultado idêntico ao trial: 25 claims, sem `amr`, sem `acr`, `acr_values_supported` vazio.

A documentação de configuração de atributos fecha a porta explicitamente:

> For OpenID Connect applications, the following claims can't be set via the configuration of attributes with default values: **acr, amr**, app_tid, at_hash, auth_time, azp, ...

Ou seja: o IAS não emite esses claims e **proíbe** criá-los por configuração. Não adianta esperar um ambiente produtivo.

### Caminho em aberto: evidência vinda do IdP corporativo

O cliente (Aché) usa **Entra ID federado ao IAS via SAML 2.0**. O Entra registra o método de autenticação em dois lugares da assertion:

| Local | Alcançável pelo IAS? |
|---|---|
| `<AuthnStatement><AuthnContext><AuthnContextClassRef>` — vale `...ac:classes:Password` ou `.../claims/multipleauthn` | **Não.** O mapeamento `${corporateIdP.*}` só enxerga o `AttributeStatement` |
| `<Attribute Name="http://schemas.microsoft.com/claims/authnmethodsreferences">` | **Sim**, se o Entra emitir. O nome `amr` é bloqueado no IAS, mas qualquer outro nome de claim é permitido |

Se o atributo vier, o desenho correto é: Entra faz o MFA → IAS repassa como claim customizado → a aplicação recusa a assinatura sem ele. Sem segundo fator próprio e sem a aplicação tocar em senha.

**Verificação pendente** (precisa do ambiente do cliente, não do trial): capturar a assertion SAML Entra → IAS com o SAML-tracer e conferir se `authnmethodsreferences` aparece dentro do `<AttributeStatement>`.

Enquanto isso não for respondido, o TOTP próprio é o plano que funciona em qualquer cenário — inclusive para RTs fora do IdP corporativo.

#### Confirmado na assertion do cliente

Captura real do fluxo do Aché (`aueuwmyhm.accounts.ondemand.com` ← Entra `24090322-b104-...`):

```xml
<Attribute Name="http://schemas.microsoft.com/claims/authnmethodsreferences">
    <AttributeValue>.../identity/authenticationmethod/password</AttributeValue>
    <AttributeValue>http://schemas.microsoft.com/claims/multipleauthn</AttributeValue>
</Attribute>
...
<AuthnContextClassRef>urn:oasis:names:tc:SAML:2.0:ac:classes:Password</AuthnContextClassRef>
```

Dois fatos:

1. O atributo **está** no `AttributeStatement` — logo é mapeável pelo IAS.
2. O `AuthnContextClassRef` diz apenas `Password` **mesmo tendo havido MFA** (push no Authenticator, visível nas chamadas `SAS/BeginAuth` e `SAS/EndAuth?authMethodId=PhoneAppNotification`). Quem confiasse nele concluiria errado.

#### Como a aplicação consome

Implementado em `srv/lib/domain/mfa.js` e ligado por variável de ambiente:

| Variável | Efeito |
|---|---|
| `MFA_CLAIM` | Nome do claim que o IAS emite com a evidência. Ausente: o TOTP próprio é obrigatório |
| `MFA_CLAIM_VALUE` | Valor procurado. Padrão `multipleauthn` |

Com `MFA_CLAIM` definido, `step-up.js` recusa a prova quando a evidência não vem — fail closed — e o evento de auditoria grava `IAS+IDP_MFA` em vez de `IAS+TOTP`. Sem a variável nada muda: o comportamento continua sendo o TOTP.

#### Roteiro para a call com o Basis do cliente

Quem conduz **não tem acesso ao IAS** — o roteiro é para guiar quem tem. Nada aqui altera aplicação existente: o teste todo acontece numa aplicação nova e descartável.

Console: `https://aueuwmyhm.accounts.ondemand.com/admin` (business users — **não** o `aarw9yamv`, de platform users).

| # | Pedido | Onde |
|---|---|---|
| 1 | Criar aplicação OIDC `TESTE - Evidencia MFA (SAPHIRA)` | *Applications & Resources* → *Applications* → Create |
| 2 | Redirect URI `http://localhost:4004/assinatura/stepup/callback` | *Trust* → *Single Sign-On* → config. OpenID Connect |
| 3 | Atributo `evidenciaMfa` com origem *Expression* e valor `${corporateIdP.http://schemas.microsoft.com/claims/authnmethodsreferences}` | *Trust* → *Single Sign-On* → *Attributes* |
| 4 | Client ID e, se exigido, client secret (por canal seguro) | mesma aplicação |
| 5 | **Só verificar**: *Use Identity Authentication user store* está habilitada? | *Identity Providers* → *Corporate Identity Providers* → o do Entra → *Identity Federation* |
| 6 | **Só perguntar**: o Entra tem *Remember MFA* ou sign-in frequency longa para o BTP? | time de identidade |

Riscos conhecidos do roteiro:

- **Passo 3 é o ponto incerto.** Não está documentado se o IAS aceita nome de atributo com URI completa. Se recusar ou salvar vazio, testar variações (`:regex[multipleauthn]`, ou pedir um alias no Entra).
- **Passo 5 não deve ser alterado na hora.** Desabilitada, o `${corporateIdP.*}` não funciona; habilitá-la afeta todas as aplicações do tenant e exige planejamento próprio.
- **Passo 6 decide se a evidência vale.** Com *Remember MFA*, o claim pode se referir a um MFA de horas antes — falso positivo para fins de assinatura. Correção: Conditional Access com *Sign-in frequency: every time* para a aplicação.

Respostas para objeções prováveis:

| Objeção | Resposta |
|---|---|
| "A política de MFA já não garante?" | Garante que acontece, não que a aplicação saiba. Desativada a política, as assinaturas seguem passando sem que nada acuse |
| "Manda o `amr` direto" | A documentação do IAS lista `acr` e `amr` entre os claims que **não** podem ser definidos por configuração de atributos |
| "Isso mexe em produção?" | Não. Aplicação nova, sem usuários atribuídos. Passos 5 e 6 são leitura |

> O IAS é do global account, não da subaccount: a mesma instância atende várias subaccounts. Os itens 1 a 4 são **por aplicação** e não afetam as demais. Os itens 5 e 6 são de tenant e exigem aval do time de identidade.

### Decisão: segundo fator próprio

Como o IAS não permite nem exigir nem comprovar o segundo fator, a aplicação passou a ter o seu, em `AssinaturaTotp` — TOTP da RFC 6238, SHA-1, 6 dígitos, passo de 30s, tolerância de um passo.

O que isso muda: antes, a garantia de dois fatores era uma configuração num outro produto, feita por outra pessoa, que não viaja com o deploy e não aparece em nenhum teste. Agora a própria aplicação verifica um fator e registra `fatores` no evento de auditoria. A evidência deixou de ser "confiamos que o IAS estava configurado" e passou a ser um fato verificável no banco.

| Fator | O que prova | Verificado por |
|---|---|---|
| IAS (`prompt=login`, `max_age=0`) | O RT reautenticou agora, com a credencial dele | `auth_time` dentro de 120s |
| TOTP | Posse do dispositivo enrolado | HMAC do segredo cifrado em repouso |

Detalhes que importam:

- O segredo é cifrado com **AES-256-GCM** antes de ir para o banco (`TOTP_ENC_KEY` em produção, `TOTP_ENC_KEY_DEV` local). Comprometer o banco não basta para assinar.
- O segredo em claro trafega **uma única vez**, na resposta de `iniciarEnrolamentoTotp`. Depois disso nunca mais sai do servidor.
- `ultimoPasso` impede replay: um código vale uma vez, não os 30 segundos inteiros.
- Falha de código conta tentativa e alimenta o bloqueio anti-brute-force existente.
- O enrolamento só vale depois de `confirmarEnrolamentoTotp` — sem isso o RT poderia se trancar fora ao não guardar o segredo corretamente.
- Não há QR code: o diálogo mostra a chave em base32 para cadastro manual. Gerar QR exigiria dependência nova no cliente.

Os vetores oficiais da RFC 6238 estão em `test/domain.test.js`.

O `sessionId` continua sendo gravado — ele é o `sid` do `id_token` e correlaciona a assinatura com o log de autenticação do IAS.

A evidência de MFA fica em três camadas:

| Camada | Evidência |
|---|---|
| Política | Risk-Based Authentication da `trial-identity-app` exigindo TOTP — configuração controlada, deve entrar no pacote de validação |
| Aplicação | `authTime` e `sessionId` em `AssinaturaStepUp` e `AssinaturaEventos`, provando reautenticação no instante da assinatura |
| Provedor | Log de autenticação do IAS (*Monitoring & Reporting*), que registra o método usado |

O `sessionId` é o `sid` do `id_token` e serve de chave de correlação entre a assinatura e a entrada específica do log do IAS.

### Por que o IAS não usa `cds bind`

Qualquer binding com label `identity` faz o CAP trocar a estratégia de autenticação da app inteira para `ias`, e isso ignora o que estiver configurado no profile — o que quebra o auth mockado de desenvolvimento. Por isso as credenciais vêm de `IAS_CREDENTIALS` (JSON do service key) no `.env` local, e de `VCAP_SERVICES` na nuvem. `getCredentials()` cobre os dois casos.

### Transações e o limite do SQLite

O audit trail de **falha** precisa de transação própria para sobreviver ao rollback que o CAP dispara ao rejeitar a operação. Isso impõe duas restrições que só aparecem no SQLite local:

1. O pool do banco precisa de mais de uma conexão (`cds.requires.db.pool.max`), senão a transação isolada espera pela conexão que o request ainda segura — e trava.
2. Só pode haver **uma** transação isolada por rejeição. SQLite aceita um escritor por vez, então duas escritas isoladas em paralelo resultam em `database is locked`.

Nenhuma das duas afeta HANA, mas ambas quebram o desenvolvimento local se ignoradas.

### Chaves em desenvolvimento

As chaves de dev ficam em `.env` e **não** são versionadas:

| Variável | Uso | Produção |
|---|---|---|
| `SIGN_HMAC_KEY_DEV` | HMAC da imagem de assinatura | `SIGN_HMAC_KEY` |
| `TOTP_ENC_KEY_DEV` | AES-256-GCM do segredo do segundo fator | `TOTP_ENC_KEY` |

Ambas base64, ≥32 bytes. Os dois módulos falham fechado: produção nunca cai na chave de desenvolvimento.

### Atenção ao rodar `deploy:local` sozinho

Os CSVs não carregam binário, então `deploy:local` recria o banco **sem** as imagens de assinatura. Com `imgData` nulo a verificação de integridade recusa toda assinatura — corretamente, mas parece bug. Use sempre `npm run setup:local`, que já encadeia o `seed`.

### HANA Cloud trial para sozinho

O plano `hana-free` desliga a instância automaticamente todo dia. Quando isso acontece, `cf service saphira-hana-cloud` continua mostrando `create succeeded` / `HanaService is ready` — isso descreve o **provisionamento**, não o **runtime**. O sintoma na aplicação é um `500` genérico:

```
Error: Pool resource could not be acquired within 1s
    at HANAService.begin (.../DatabaseService.js:66:27)
```

O erro verdadeiro (`HANA Database instance is stopped`) só aparece se o pool tiver tempo de propagá-lo — por isso `cds.requires.[production].db.pool.acquireTimeoutMillis` foi elevado para 20s no `package.json`. Para religar:

```powershell
'{ "data": { "serviceStopped": false } }' | Out-File -Encoding ascii hana-start.json
cf update-service saphira-hana-cloud -c hana-start.json
```

Leva alguns minutos. Acompanhe com `cf service saphira-hana-cloud`.

Para diagnosticar conectividade de dentro do container, sem redeploy:

```powershell
$js = 'import cds from "@sap/cds"; try { await cds.connect.to("db"); console.log("OK", await SELECT.one.from("saphira.assinatura.Livros")); } catch (e) { console.log("FAIL", e.message); } process.exit(0);'
$b64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($js))
cf run-task saphira-assinatura-srv-srv --command "echo $b64 | base64 -d > /home/vcap/app/probe.mjs; node /home/vcap/app/probe.mjs" --name probe
cf logs saphira-assinatura-srv-srv --recent | Select-String 'OK|FAIL'
```

### A política de MFA não viaja com o deploy

A exigência de segundo fator **no IAS** é configuração do tenant, presa ao `clientid` da aplicação criada pelo binding. Cada ambiente gera uma aplicação nova e começa sem MFA, silenciosamente — nada no build, no `mta.yaml` ou nos testes acusa isso.

Foi exatamente esse buraco que motivou o TOTP próprio: a assinatura não depende mais dessa configuração. A política do IAS continua recomendada como defesa em profundidade, mas deixou de ser a única coisa entre um invasor com a senha do RT e uma assinatura válida.

