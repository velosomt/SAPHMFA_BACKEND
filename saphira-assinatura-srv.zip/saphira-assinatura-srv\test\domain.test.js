import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { bloqueioAtivo, provaUtilizavel, rtElegivel } from '../srv/lib/domain/elegibilidade.js';
import { contextoDaAcao, enderecoDaImagem, statusAposAcao } from '../srv/lib/domain/contexto.js';
import { codigoDe, montarOtpauthUri, paraBase32, passoDe, verificarCodigo } from '../srv/lib/domain/totp.js';
import { comprovaSegundoFator, extrairEvidencia } from '../srv/lib/domain/mfa.js';

const HOJE = new Date('2026-09-10T12:00:00Z');

describe('rtElegivel', () => {
  it('aceita RT ativo dentro da validade', () => {
    assert.equal(rtElegivel({ status: 'ATIVO', validoDe: '2026-01-01', validoAte: '2027-12-31' }, HOJE), true);
  });

  it('recusa RT inativo', () => {
    assert.equal(rtElegivel({ status: 'INATIVO', validoAte: '2027-12-31' }, HOJE), false);
  });

  it('recusa RT com validade vencida', () => {
    assert.equal(rtElegivel({ status: 'ATIVO', validoAte: '2026-06-30' }, HOJE), false);
  });

  it('recusa RT cuja validade ainda nao comecou', () => {
    assert.equal(rtElegivel({ status: 'ATIVO', validoDe: '2026-10-01' }, HOJE), false);
  });

  it('aceita quando nao ha datas de validade', () => {
    assert.equal(rtElegivel({ status: 'ATIVO' }, HOJE), true);
  });

  it('aceita no proprio dia de vencimento', () => {
    assert.equal(rtElegivel({ status: 'ATIVO', validoAte: '2026-09-10' }, HOJE), true);
  });

  it('recusa RT inexistente', () => {
    assert.equal(rtElegivel(undefined, HOJE), false);
  });
});

describe('provaUtilizavel', () => {
  const valida = {
    login: 'rt@ache.com.br',
    status: 'PROVADO',
    validUntil: '2026-09-10T12:01:00Z'
  };

  it('aceita prova valida do proprio usuario', () => {
    assert.deepEqual(provaUtilizavel(valida, 'rt@ache.com.br', HOJE), { ok: true });
  });

  it('recusa prova inexistente', () => {
    assert.equal(provaUtilizavel(null, 'rt@ache.com.br', HOJE).ok, false);
  });

  it('recusa prova de outro usuario', () => {
    assert.match(provaUtilizavel(valida, 'outro@ache.com.br', HOJE).motivo, /outro usuario/);
  });

  it('recusa prova ja consumida', () => {
    assert.match(provaUtilizavel({ ...valida, status: 'CONSUMIDO' }, 'rt@ache.com.br', HOJE).motivo, /CONSUMIDO/);
  });

  it('recusa prova expirada', () => {
    const expirada = { ...valida, validUntil: '2026-09-10T11:59:00Z' };
    assert.match(provaUtilizavel(expirada, 'rt@ache.com.br', HOJE).motivo, /expirada/);
  });
});

describe('bloqueioAtivo', () => {
  it('bloqueia enquanto a janela nao venceu', () => {
    assert.equal(bloqueioAtivo({ blockedUntil: '2026-09-10T12:00:30Z' }, HOJE), true);
  });

  it('libera depois da janela', () => {
    assert.equal(bloqueioAtivo({ blockedUntil: '2026-09-10T11:59:30Z' }, HOJE), false);
  });

  it('libera quando nunca houve falha', () => {
    assert.equal(bloqueioAtivo(undefined, HOJE), false);
  });
});

describe('contexto da acao', () => {
  const livro = { numero: '003', substancia: 'DIAZEPAM 10MG' };

  it('monta o texto exibido no dialogo', () => {
    assert.equal(contextoDaAcao('ENCERRAR_LIVRO', livro), 'Encerramento do Livro 003 - DIAZEPAM 10MG');
  });

  it('nao quebra com tipo de acao desconhecido', () => {
    assert.equal(contextoDaAcao('OUTRA_COISA', livro), 'OUTRA_COISA 003 - DIAZEPAM 10MG');
  });

  it('so encerrar muda o status do livro', () => {
    assert.equal(statusAposAcao('ENCERRAR_LIVRO'), 'ENCERRADO');
    assert.equal(statusAposAcao('IMPRIMIR'), undefined);
    assert.equal(statusAposAcao('TERMO_ABERTURA'), undefined);
  });

  it('monta o endereco da imagem sem embutir o binario', () => {
    assert.equal(enderecoDaImagem('abc-123'), 'ResponsaveisTecnicos(abc-123)/imgData');
  });
});

describe('totp', () => {
  // Vetores da RFC 6238, apendice B (SHA-1, 8 digitos).
  const SEGREDO = Buffer.from('12345678901234567890', 'ascii');
  const VETORES = [
    [59, '94287082'],
    [1111111109, '07081804'],
    [1111111111, '14050471'],
    [1234567890, '89005924'],
    [2000000000, '69279037'],
    [20000000000, '65353130']
  ];

  for (const [instanteSegundos, esperado] of VETORES) {
    it(`gera o codigo da RFC 6238 em T=${instanteSegundos}`, () => {
      assert.equal(codigoDe(SEGREDO, passoDe(instanteSegundos * 1000, 30), 8), esperado);
    });
  }

  it('codifica em base32 sem padding', () => {
    assert.equal(paraBase32(Buffer.from('12345678901234567890', 'ascii')), 'GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ');
  });

  const codigoEm = (instanteMs) => codigoDe(SEGREDO, passoDe(instanteMs, 30), 6);

  it('aceita o codigo do passo atual', () => {
    const agora = Date.now();
    const { ok } = verificarCodigo({ segredo: SEGREDO, codigo: codigoEm(agora), instanteMs: agora });
    assert.equal(ok, true);
  });

  it('aceita o codigo do passo anterior dentro da tolerancia', () => {
    const agora = Date.now();
    const { ok } = verificarCodigo({ segredo: SEGREDO, codigo: codigoEm(agora - 30_000), instanteMs: agora });
    assert.equal(ok, true);
  });

  it('recusa codigo fora da janela de tolerancia', () => {
    const agora = Date.now();
    const { ok } = verificarCodigo({ segredo: SEGREDO, codigo: codigoEm(agora - 120_000), instanteMs: agora });
    assert.equal(ok, false);
  });

  it('recusa replay de um passo ja consumido', () => {
    const agora = Date.now();
    const passo = passoDe(agora, 30);
    const { ok, motivo } = verificarCodigo({
      segredo: SEGREDO,
      codigo: codigoEm(agora),
      instanteMs: agora,
      ultimoPasso: passo
    });
    assert.equal(ok, false);
    assert.match(motivo, /ja utilizado/);
  });

  it('recusa codigo com formato invalido antes de calcular qualquer HMAC', () => {
    const { ok } = verificarCodigo({ segredo: SEGREDO, codigo: '12ab', instanteMs: Date.now() });
    assert.equal(ok, false);
  });

  it('monta o otpauth com emissor e algoritmo explicitos', () => {
    const uri = montarOtpauthUri({
      emissor: 'SAPHIRA',
      conta: 'm.morita@ache.com.br',
      segredoBase32: 'GEZDGNBV',
      digitos: 6,
      passoSegundos: 30
    });
    assert.match(uri, /^otpauth:\/\/totp\/SAPHIRA%3Am\.morita%40ache\.com\.br\?/);
    assert.match(uri, /secret=GEZDGNBV/);
    assert.match(uri, /algorithm=SHA1/);
  });
});

describe('evidencia de MFA do IdP corporativo', () => {
  const CLAIM = 'authnMethods';
  const PASSWORD = 'http://schemas.microsoft.com/ws/2008/06/identity/authenticationmethod/password';
  const MFA = 'http://schemas.microsoft.com/claims/multipleauthn';

  it('reconhece o segundo fator quando o Entra devolve multipleauthn', () => {
    const evidencia = extrairEvidencia({ [CLAIM]: [PASSWORD, MFA] }, CLAIM);
    assert.equal(comprovaSegundoFator(evidencia, 'multipleauthn'), true);
  });

  it('recusa quando so houve senha', () => {
    const evidencia = extrairEvidencia({ [CLAIM]: [PASSWORD] }, CLAIM);
    assert.equal(comprovaSegundoFator(evidencia, 'multipleauthn'), false);
  });

  it('aceita valor unico fora de array', () => {
    const evidencia = extrairEvidencia({ [CLAIM]: MFA }, CLAIM);
    assert.equal(comprovaSegundoFator(evidencia, 'multipleauthn'), true);
  });

  it('recusa quando o claim nao veio - sem evidencia nao ha prova', () => {
    const evidencia = extrairEvidencia({ email: 'a@b.com' }, CLAIM);
    assert.deepEqual(evidencia, []);
    assert.equal(comprovaSegundoFator(evidencia, 'multipleauthn'), false);
  });
});
