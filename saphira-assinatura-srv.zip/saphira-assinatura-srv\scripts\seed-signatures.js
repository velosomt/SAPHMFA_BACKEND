import cds from '@sap/cds';
import { semearAssinaturas } from '../srv/lib/usecases/semear-assinaturas.js';

const LOG = cds.log('seed');

try {
  cds.model ??= cds.linked(await cds.load('*'));
  await cds.connect.to('db');

  const gravadas = await semearAssinaturas();
  for (const rt of gravadas) {
    LOG.info(`${rt.login.padEnd(28)} ${rt.imgData.length} bytes  ${rt.imgHash.slice(0, 16)}...`);
  }
  LOG.info(`${gravadas.length} assinaturas gravadas com ${gravadas[0].hashAlg}`);
  process.exit(0);
} catch (erro) {
  LOG.error(erro.message);
  process.exit(1);
}
