import cds from '@sap/cds';
import { config } from './lib/config.js';
import { AssinaturaError, MENSAGENS } from './lib/errors.js';
import { prepararAssinatura } from './lib/usecases/preparar-assinatura.js';
import { assinarEletronicamente } from './lib/usecases/assinar-eletronicamente.js';
import { confirmarEnrolamentoTotp, iniciarEnrolamentoTotp } from './lib/usecases/totp.js';
import { emitirProvaMock } from './lib/usecases/step-up.js';

/** Traduz o request do CAP no contexto que os casos de uso esperam. */
const contextoDe = (req) => ({
  tx: cds.tx(req),
  login: req.user.id,
  ip: req.http?.req?.ip,
  ...req.data
});

/** Erro de negocio vira resposta HTTP; qualquer outro sobe e vira 500. */
const executar = async (req, casoDeUso) => {
  try {
    return await casoDeUso(contextoDe(req));
  } catch (erro) {
    if (erro instanceof AssinaturaError) return req.reject(erro.status, erro.mensagem);
    throw erro;
  }
};

export default (srv) => {
  srv.on('prepararAssinatura', (req) => executar(req, prepararAssinatura));
  srv.on('assinarEletronicamente', (req) => executar(req, assinarEletronicamente));
  srv.on('iniciarEnrolamentoTotp', (req) => executar(req, iniciarEnrolamentoTotp));
  srv.on('confirmarEnrolamentoTotp', (req) => executar(req, confirmarEnrolamentoTotp));

  srv.on('provarStepUpMock', async (req) => {
    // Fora de desenvolvimento o emissor falso nao existe. Ver pendencia P7 no readme.
    if (config.producao) return req.reject(501, MENSAGENS.mockIndisponivel);

    const proofId = await emitirProvaMock(req.data.stepUpId);
    if (!proofId) return req.reject(400, MENSAGENS.stepUpInvalido);
    return proofId;
  });
};
