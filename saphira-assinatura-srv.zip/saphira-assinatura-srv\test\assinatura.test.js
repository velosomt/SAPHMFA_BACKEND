﻿import assert from 'node:assert/strict';
import { before, beforeEach, describe, it } from 'node:test';
import cds from '@sap/cds';
import { calcularDigest } from '../srv/lib/infra/signature-hash.js';
import { buildSignaturePng } from '../srv/lib/infra/signature-image.js';
import { codigoDe, passoDe } from '../srv/lib/domain/totp.js';
import { decifrar } from '../srv/lib/infra/totp-secret.js';
import { EVENTOS, LIVROS, RT_ASSINATURA, TENTATIVAS, TOTP } from '../srv/lib/entities.js';

// Banco proprio dos testes, recriado pelo passo pretest.
process.env.CDS_REQUIRES_DB_CREDENTIALS_URL = 'test.sqlite';

// A suite cobre a estrategia de TOTP; o padrao da aplicacao e fail open.
process.env.TOTP_OBRIGATORIO = 'true';

const test = cds.test(process.cwd());
const { POST, GET, axios } = test;
axios.defaults.validateStatus = () => true;

const LIVRO_003 = 'b71e5a90-2c44-4d55-8e66-0f1a2b3c4d01';
const MORITA = 'm.morita@ache.com.br';
const PEREIRA = 'j.pereira@ache.com.br';
const SOUZA = 'a.souza@ache.com.br';

const como = (login) => ({ auth: { username: login, password: 'local' } });

const semearImagens = async () => {
  const { SELECT, UPSERT } = cds.ql;
  const responsaveis = await SELECT.from(RT_ASSINATURA);
  const comImagem = await Promise.all(responsaveis.map(async (rt) => {
    const imgData = buildSignaturePng(rt.login);
    const { digest, algoritmo, versaoChave } = await calcularDigest(imgData);
    return { ...rt, imgData, imgMimeType: 'image/png', imgHash: digest, hashAlg: algoritmo, keyVersion: versaoChave };
  }));
  await UPSERT.into(RT_ASSINATURA).entries(comImagem);
};

const preparar = async (login, tipoAcao = 'ENCERRAR_LIVRO') =>
  GET(`/odata/v4/assinatura/prepararAssinatura(tipoAcao='${tipoAcao}',objetoId=${LIVRO_003})`, como(login));

/** Gera o codigo como o aplicativo autenticador do RT geraria. */
const codigoAtual = async (login) => {
  const registro = await cds.ql.SELECT.one.from(TOTP)
    .columns('segredo', 'keyVersion', 'digitos', 'passoSegundos').where({ login });
  if (!registro) return '000000';

  const segredo = decifrar(registro.segredo, registro.keyVersion);
  return codigoDe(segredo, passoDe(Date.now(), registro.passoSegundos), registro.digitos);
};

const enrolarTotp = async (login) => {
  await POST('/odata/v4/assinatura/iniciarEnrolamentoTotp', {}, como(login));
  return POST('/odata/v4/assinatura/confirmarEnrolamentoTotp', { codigo: await codigoAtual(login) }, como(login));
};

// Action que retorna escalar em OData V4 vem embrulhada em { value }.
const provar = async (login, stepUpId) => {
  const { data } = await POST('/odata/v4/assinatura/provarStepUpMock', { stepUpId }, como(login));
  return data?.value ?? data;
};

const assinar = async (login, proofId, declaracaoConformidade = true, codigoTotp = null) =>
  POST('/odata/v4/assinatura/assinarEletronicamente', {
    proofId,
    declaracaoConformidade,
    codigoTotp: codigoTotp ?? await codigoAtual(login)
  }, como(login));

describe('Assinatura eletronica', () => {

  before(async () => {
    await test;
    await semearImagens();
    await enrolarTotp(MORITA);
  });

  beforeEach(async () => {
    await cds.ql.DELETE.from(TENTATIVAS);
    // O anti-replay tem teste proprio no dominio; aqui ele so atrapalharia a sequencia.
    await cds.ql.UPDATE(TOTP).set({ ultimoPasso: null });
  });

  it('recusa RT inativo antes de pedir qualquer credencial', async () => {
    const { status } = await preparar(PEREIRA);
    assert.equal(status, 403);
  });

  it('recusa RT com validade vencida', async () => {
    const { status } = await preparar(SOUZA);
    assert.equal(status, 403);
  });

  it('monta o contexto e devolve o endereco da imagem, nao a imagem', async () => {
    const { status, data } = await preparar(MORITA);
    assert.equal(status, 200);
    assert.equal(data.contexto, 'Encerramento do Livro 003 - DIAZEPAM 10MG');
    assert.equal(data.rtId, 'RT-7F3A-9B8E-C124');
    assert.match(data.imagemUrl, /^ResponsaveisTecnicos\(.+\)\/imgData$/);
    assert.ok(data.stepUpId);
    assert.equal(data.totpAtivo, true);
  });

  it('assina, grava a evidencia no livro e registra o evento', async () => {
    const { data: preparo } = await preparar(MORITA);
    const proofId = await provar(MORITA, preparo.stepUpId);

    const { status, data } = await assinar(MORITA, proofId);
    assert.equal(status, 200);
    assert.ok(data.signId);
    assert.equal(data.rtId, 'RT-7F3A-9B8E-C124');

    const livro = await cds.ql.SELECT.one.from(LIVROS).where({ ID: LIVRO_003 });
    assert.equal(livro.signId, data.signId);
    assert.equal(livro.status, 'ENCERRADO');
    assert.equal(livro.signImageHash, data.signImageHash);

    const evento = await cds.ql.SELECT.one.from(EVENTOS)
      .where({ signId: data.signId, evento: 'EVT_ASSINATURA' });
    assert.ok(evento);
    assert.equal(evento.login, MORITA);
    assert.equal(evento.fatores, 'IAS+TOTP');
  });

  it('recusa assinatura com codigo do segundo fator errado', async () => {
    const { data: preparo } = await preparar(MORITA, 'IMPRIMIR');
    const proofId = await provar(MORITA, preparo.stepUpId);

    const { status } = await assinar(MORITA, proofId, true, '000000');
    assert.equal(status, 401);
  });

  it('recusa assinatura de RT que nao cadastrou o segundo fator', async () => {
    const { data: preparo } = await preparar(MORITA, 'IMPRIMIR');
    const proofId = await provar(MORITA, preparo.stepUpId);
    await cds.ql.UPDATE(TOTP).set({ ativadoEm: null }).where({ login: MORITA });

    const { status } = await assinar(MORITA, proofId, true, '123456');
    assert.equal(status, 401);

    await cds.ql.UPDATE(TOTP).set({ ativadoEm: new Date().toISOString() }).where({ login: MORITA });
  });

  it('recusa declaracao desmarcada sem contar tentativa', async () => {
    const { data: preparo } = await preparar(MORITA);
    const proofId = await provar(MORITA, preparo.stepUpId);

    const { status } = await assinar(MORITA, proofId, false);
    assert.equal(status, 401);

    const tentativa = await cds.ql.SELECT.one.from(TENTATIVAS).where({ login: MORITA });
    assert.equal(tentativa, undefined);
  });

  it('recusa prova emitida para outro usuario e bloqueia por 30s', async () => {
    const { data: preparo } = await preparar(MORITA);
    const proofId = await provar(MORITA, preparo.stepUpId);

    const primeira = await assinar(SOUZA, proofId);
    assert.equal(primeira.status, 401);

    const segunda = await assinar(SOUZA, proofId);
    assert.equal(segunda.status, 429);
  });

  it('registra a falha mesmo com a operacao rejeitada', async () => {
    const antes = await cds.ql.SELECT.from(EVENTOS).where({ evento: 'EVT_ASSINATURA_FALHA' });
    await assinar(MORITA, 'proof-inexistente');
    const depois = await cds.ql.SELECT.from(EVENTOS).where({ evento: 'EVT_ASSINATURA_FALHA' });
    assert.equal(depois.length, antes.length + 1);
  });

  it('recusa replay do mesmo proofId', async () => {
    const { data: preparo } = await preparar(MORITA, 'IMPRIMIR');
    const proofId = await provar(MORITA, preparo.stepUpId);

    assert.equal((await assinar(MORITA, proofId)).status, 200);
    assert.equal((await assinar(MORITA, proofId)).status, 401);
  });

  it('recusa quando a imagem no banco foi adulterada', async () => {
    const { data: preparo } = await preparar(MORITA, 'IMPRIMIR');
    const proofId = await provar(MORITA, preparo.stepUpId);

    const adulterada = buildSignaturePng('outro-tracado-qualquer');
    await cds.ql.UPDATE(RT_ASSINATURA).set({ imgData: adulterada }).where({ login: MORITA });

    const { status } = await assinar(MORITA, proofId);
    assert.equal(status, 401);

    await semearImagens();
  });

  it('nao permite um RT ler a imagem de assinatura de outro', async () => {
    const alvo = await cds.ql.SELECT.one.from(RT_ASSINATURA).columns('ID').where({ login: PEREIRA });
    const { status } = await GET(`/odata/v4/assinatura/ResponsaveisTecnicos(${alvo.ID})`, como(MORITA));
    assert.notEqual(status, 200);
  });
});

