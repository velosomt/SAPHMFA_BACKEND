import cds from '@sap/cds';
import { config } from './lib/config.js';
import { concluir } from './lib/usecases/step-up.js';

const LOG = cds.log('stepup');

/** Devolve a prova para a janela que abriu o popup e fecha. Nenhum dado sensivel trafega. */
const paginaResultado = (payload, origem) => `<!DOCTYPE html>
<html lang="pt-BR"><head><meta charset="utf-8">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'">
<title>Assinatura</title></head>
<body><script>
  window.opener && window.opener.postMessage(${JSON.stringify(payload)}, ${JSON.stringify(origem)});
  window.close();
</script></body></html>`;

cds.on('bootstrap', (app) => {
  // Fail open e decisao consciente de PoC. Em producao tem que haver segundo fator.
  if (config.mfa.ausente) {
    LOG.warn('nenhuma prova de segundo fator exigida. Defina MFA_CLAIM ou TOTP_OBRIGATORIO antes de produzir.');
  }

  // Rota publica de proposito: e o redirect_uri do IAS, chamado antes de haver sessao na app.
  app.get(config.callbackPath, async (req, res) => {
    const origem = config.origemUi;
    const { code, state } = req.query;

    if (!code || !state) {
      res.status(400).type('html').send(paginaResultado({ tipo: 'stepup', erro: true }, origem));
      return;
    }

    try {
      const { proofId } = await concluir({ code, state });
      res.type('html').send(paginaResultado({ tipo: 'stepup', proofId }, origem));
    } catch (erro) {
      // Motivo so no log do servidor - a janela recebe apenas "deu errado".
      LOG.warn('step-up recusado:', erro.message);
      res.status(401).type('html').send(paginaResultado({ tipo: 'stepup', erro: true }, origem));
    }
  });
});

export default cds.server;
