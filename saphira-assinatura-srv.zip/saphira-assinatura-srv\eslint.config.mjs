import cds from '@sap/cds/eslint.config.mjs'
export default [
  { ignores: ['gen/**', 'node_modules/**', '@cds-models/**'] },
  ...cds.recommended
]
