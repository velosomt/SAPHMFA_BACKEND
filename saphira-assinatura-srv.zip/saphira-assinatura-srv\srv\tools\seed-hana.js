import cds from '@sap/cds';
import { semearAssinaturas } from '../lib/usecases/semear-assinaturas.js';

const LOG = cds.log('seed');

// Tarefa administrativa executada via `cf run-task`, dentro do container - usa os bindings da app.
try {
  cds.model ??= cds.linked(await cds.load('*'));
  await cds.connect.to('db');

  const gravadas = await semearAssinaturas();
  for (const rt of gravadas) {
    LOG.info(`${rt.login} ${rt.imgData.length} bytes ${rt.imgHash.slice(0, 16)}... chave=${rt.keyVersion}`);
  }
  LOG.info(`${gravadas.length} assinaturas gravadas`);
  process.exit(0);
} catch (erro) {
  LOG.error(erro.message);
  process.exit(1);
}
