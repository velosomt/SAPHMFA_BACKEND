namespace saphira.assinatura;

type IasLogin : String(120);
type RtId     : String(22);
type SignId   : String(36);
type Contexto : String(200);

/** Hex de SHA-256 ou HMAC-SHA256 (64 chars); folga para algoritmos maiores. */
type Digest : String(128);

type RtStatus : String(10) enum {
  ativo    = 'ATIVO';
  inativo  = 'INATIVO';
  suspenso = 'SUSPENSO';
};

type LivroStatus : String(12) enum {
  aberto    = 'ABERTO';
  assinado  = 'ASSINADO';
  encerrado = 'ENCERRADO';
};

type EventoTipo : String(30) enum {
  assinatura      = 'EVT_ASSINATURA';
  assinaturaFalha = 'EVT_ASSINATURA_FALHA';
  stepUpIniciado  = 'EVT_STEPUP_INICIADO';
  stepUpFalha     = 'EVT_STEPUP_FALHA';
  totpEnrolado    = 'EVT_TOTP_ENROLADO';
};

/** Fatores efetivamente verificados na assinatura. Evidencia, nao configuracao. */
type Fatores : String(40);

type StepUpStatus : String(10) enum {
  pendente  = 'PENDENTE';
  provado   = 'PROVADO';
  consumido = 'CONSUMIDO';
  expirado  = 'EXPIRADO';
};

type TipoAcao : String(24) enum {
  imprimir          = 'IMPRIMIR';
  termoAbertura     = 'TERMO_ABERTURA';
  termoEncerramento = 'TERMO_ENCERRAMENTO';
  encerrarLivro     = 'ENCERRAR_LIVRO';
};

/** Referencia polimorfica: a assinatura e generica por acao, nao presa a Livros. */
type ObjetoTipo : String(20);
