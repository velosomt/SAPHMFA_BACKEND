sap.ui.define([
  "sap/ui/core/UIComponent",
  "sap/ui/Device",
  "sap/ui/model/json/JSONModel"
], (UIComponent, Device, JSONModel) => {
  "use strict";

  return UIComponent.extend("com.saphira.assinatura.Component", {

    metadata: {
      manifest: "json",
      interfaces: ["sap.ui.core.IAsyncContentCreation"]
    },

    init() {
      UIComponent.prototype.init.call(this);
      this.setModel(new JSONModel({ isPhone: Device.system.phone }), "device");
      this.getContentDensityClass();
    },

    getContentDensityClass() {
      this._sContentDensityClass ??= Device.support.touch ? "sapUiSizeCozy" : "sapUiSizeCompact";
      return this._sContentDensityClass;
    }
  });
});
