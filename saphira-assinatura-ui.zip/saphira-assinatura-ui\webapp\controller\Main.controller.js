sap.ui.define([
  "./BaseController",
  "../model/formatter",
  "sap/ui/model/json/JSONModel",
  "sap/ui/core/Fragment",
  "sap/m/MessageBox",
  "sap/m/MessageToast",
  "sap/base/Log"
], (BaseController, formatter, JSONModel, Fragment, MessageBox, MessageToast, Log) => {
  "use strict";

  const POPUP_FEATURES = "width=560,height=700,menubar=no,toolbar=no,location=yes";
  const ESTADO_INICIAL = {
    contexto: "",
    login: "",
    rtId: "",
    nome: "",
    imagemSrc: "",
    stepUpId: "",
    authorizeUrl: null,
    callbackOrigin: "",
    tipoAcao: "",
    declaracao: false,
    exigeTotp: true,
    totpAtivo: false,
    proofId: "",
    codigoTotp: "",
    ocupado: false
  };
  const TOTP_INICIAL = { segredo: "", codigo: "", ocupado: false };

  return BaseController.extend("com.saphira.assinatura.controller.Main", {

    formatter,

    onInit() {
      this.setModel(new JSONModel({ ...ESTADO_INICIAL }), "assinatura");
      this.setModel(new JSONModel({ ...TOTP_INICIAL }), "totp");
      this.setModel(new JSONModel({ livroSelecionado: null }), "ui");
    },

    onExit() {
      this._pDialog?.then((oDialog) => oDialog.destroy());
      this._pTotpDialog?.then((oDialog) => oDialog.destroy());
      this._pDialog = null;
      this._pTotpDialog = null;
    },

    onSelecionarLivro(oEvent) {
      const oContext = oEvent.getParameter("listItem")?.getBindingContext();
      this.getModel("ui").setProperty("/livroSelecionado", oContext?.getObject() ?? null);
    },

    async onAcaoPress(oEvent) {
      const sTipoAcao = oEvent.getSource().data("tipoAcao");
      const oLivro = this.getModel("ui").getProperty("/livroSelecionado");

      if (!oLivro) {
        MessageToast.show(this.getText("selecioneLivro"));
        return;
      }

      try {
        const oPreparo = await this._prepararAssinatura(sTipoAcao, oLivro.ID);
        this.getModel("assinatura").setData({
          ...ESTADO_INICIAL,
          ...oPreparo,
          tipoAcao: sTipoAcao,
          imagemSrc: this.getServiceUrl() + oPreparo.imagemUrl
        });
        const oDialog = await this._carregarDialog();
        oDialog.open();
      } catch (oError) {
        this._mostrarErro(oError);
      }
    },

    /** Etapa 1: reautenticacao no IAS. So depois dela o codigo do autenticador e pedido. */
    async onConfirmarIdentidadePress() {
      const oModel = this.getModel("assinatura");
      oModel.setProperty("/ocupado", true);

      try {
        oModel.setProperty("/proofId", await this._obterProva(oModel.getData()));
        if (oModel.getProperty("/exigeTotp")) this.byId("inpCodigoTotp").focus();
      } catch (oError) {
        this._mostrarErro(oError);
      } finally {
        oModel.setProperty("/ocupado", false);
      }
    },

    /** Etapa 2: segundo fator proprio. A prova do IAS ja esta no modelo. */
    async onAssinarPress() {
      const oModel = this.getModel("assinatura");
      oModel.setProperty("/ocupado", true);

      try {
        const oResultado = await this._assinar(
          oModel.getProperty("/proofId"),
          oModel.getProperty("/declaracao"),
          oModel.getProperty("/codigoTotp")
        );

        this.onCancelarPress();
        this.byId("tabLivros").getBinding("items").refresh();
        MessageBox.success(this.getText("assinaturaConcluida", [
          oResultado.signId,
          oResultado.signImageHash.slice(0, 16)
        ]));
      } catch (oError) {
        // A prova e de uso unico: se a assinatura falhou, ela ja nao serve mais.
        oModel.setProperty("/proofId", "");
        oModel.setProperty("/codigoTotp", "");
        this._mostrarErro(oError);
      } finally {
        oModel.setProperty("/ocupado", false);
      }
    },

    onCancelarPress() {
      this._pDialog?.then((oDialog) => oDialog.close());
    },

    /** O segredo so trafega neste momento; depois disso nunca mais sai do servidor. */
    async onCadastrarTotpPress() {
      try {
        const oEnrolamento = await this._invocar("iniciarEnrolamentoTotp");
        this.getModel("totp").setData({ ...TOTP_INICIAL, segredo: oEnrolamento.segredo });

        const oDialog = await this._carregarTotpDialog();
        oDialog.open();
      } catch (oError) {
        this._mostrarErro(oError);
      }
    },

    async onConfirmarTotpPress() {
      const oModel = this.getModel("totp");
      oModel.setProperty("/ocupado", true);

      try {
        await this._invocar("confirmarEnrolamentoTotp", { codigo: oModel.getProperty("/codigo") });
        this.onCancelarTotpPress();
        this.onCancelarPress();
        MessageToast.show(this.getText("totpConfirmado"));
      } catch (oError) {
        this._mostrarErro(oError);
      } finally {
        oModel.setProperty("/ocupado", false);
      }
    },

    onCancelarTotpPress() {
      this._pTotpDialog?.then((oDialog) => oDialog.close());
      this.getModel("totp").setData({ ...TOTP_INICIAL });
    },

    _carregarDialog() {
      this._pDialog ??= Fragment.load({
        id: this.getView().getId(),
        name: "com.saphira.assinatura.fragment.AssinaturaEletronica",
        controller: this
      }).then((oDialog) => {
        this.getView().addDependent(oDialog);
        return oDialog;
      });
      return this._pDialog;
    },

    _carregarTotpDialog() {
      this._pTotpDialog ??= Fragment.load({
        id: this.getView().getId(),
        name: "com.saphira.assinatura.fragment.EnrolamentoTotp",
        controller: this
      }).then((oDialog) => {
        this.getView().addDependent(oDialog);
        return oDialog;
      });
      return this._pTotpDialog;
    },

    async _invocar(sAction, oParametros = {}) {
      const oBinding = this.getModel().bindContext(`/${sAction}(...)`);
      for (const [sChave, vValor] of Object.entries(oParametros)) {
        oBinding.setParameter(sChave, vValor);
      }
      await oBinding.invoke();
      return oBinding.getBoundContext().getObject();
    },

    async _prepararAssinatura(sTipoAcao, sObjetoId) {
      const oBinding = this.getModel().bindContext("/prepararAssinatura(...)");
      oBinding.setParameter("tipoAcao", sTipoAcao);
      oBinding.setParameter("objetoId", sObjetoId);
      await oBinding.invoke();
      return oBinding.getBoundContext().getObject();
    },

    /**
     * A senha e a reautenticacao acontecem na janela do IAS, nunca nesta app.
     * De volta vem apenas o proofId. O segundo fator e verificado pelo servidor
     * com o codigo digitado aqui - o IAS nao informa quais fatores foram usados.
     */
    _obterProva(oEstado) {
      return oEstado.authorizeUrl
        ? this._obterProvaViaIas(oEstado)
        : this._obterProvaMock(oEstado.stepUpId);
    },

    _obterProvaViaIas({ authorizeUrl, callbackOrigin }) {
      return new Promise((resolve, reject) => {
        const oPopup = window.open(authorizeUrl, "saphiraStepUp", POPUP_FEATURES);
        if (!oPopup) {
          reject(new Error(this.getText("popupBloqueado")));
          return;
        }

        let iVigia = null;
        const fnLimpar = () => {
          clearInterval(iVigia);
          window.removeEventListener("message", fnMensagem);
        };

        const fnMensagem = (oEvent) => {
          if (oEvent.origin !== callbackOrigin || oEvent.source !== oPopup) return;
          if (oEvent.data?.tipo !== "stepup") return;
          fnLimpar();
          if (oEvent.data.proofId) resolve(oEvent.data.proofId);
          else reject(new Error(this.getText("stepUpRecusado")));
        };

        window.addEventListener("message", fnMensagem);
        iVigia = setInterval(() => {
          if (!oPopup.closed) return;
          fnLimpar();
          reject(new Error(this.getText("stepUpCancelado")));
        }, 500);
      });
    },

    /** Fallback de desenvolvimento: so existe quando nao ha binding do IAS. */
    async _obterProvaMock(sStepUpId) {
      const oBinding = this.getModel().bindContext("/provarStepUpMock(...)");
      oBinding.setParameter("stepUpId", sStepUpId);
      await oBinding.invoke();
      return oBinding.getBoundContext().getObject().value;
    },

    _assinar(sProofId, bDeclaracao, sCodigoTotp) {
      return this._invocar("assinarEletronicamente", {
        proofId: sProofId,
        declaracaoConformidade: bDeclaracao,
        codigoTotp: sCodigoTotp
      });
    },

    _mostrarErro(oError) {
      Log.error("Falha no fluxo de assinatura", oError);
      MessageBox.error(oError?.error?.message ?? oError?.message ?? this.getText("erroGenerico"));
    }
  });
});
