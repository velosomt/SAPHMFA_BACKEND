sap.ui.define([], () => {
  "use strict";

  return {
    statusLivro(sStatus) {
      switch (sStatus) {
        case "ENCERRADO":
          return "Success";
        case "ASSINADO":
          return "Warning";
        default:
          return "Information";
      }
    }
  };
});
