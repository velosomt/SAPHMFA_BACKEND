sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (Controller) => {
  "use strict";

  return Controller.extend("com.saphira.assinatura.controller.BaseController", {

    getModel(sName) {
      return this.getView().getModel(sName);
    },

    setModel(oModel, sName) {
      this.getView().setModel(oModel, sName);
      return this;
    },

    getBundle() {
      return this.getOwnerComponent().getModel("i18n").getResourceBundle();
    },

    getText(sKey, aArgs) {
      return this.getBundle().getText(sKey, aArgs);
    },

    /** URL absoluta do servico, lida do manifest - nunca de API privada do model. */
    getServiceUrl() {
      return this.getOwnerComponent().getManifestEntry("/sap.app/dataSources/assinaturaService/uri");
    }
  });
});
